# MachineDemo

This is the main project for MachineDemo. It only implements 
an application class and a dependency injection for the 
machine that is passed on to MachineDemoLib that implements
the actual demonstration program. MachineDemoLib is 
automatically pulled from github by CMake rather than
being permanently included in this project.

**Do not modify any part of MachineDemo!**
