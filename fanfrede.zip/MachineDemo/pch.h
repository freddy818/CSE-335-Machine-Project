/**
 * @file pch.h
 * @author Charles B. Owen
 *
 * Do not modify this file!
 */

#ifndef MACHINEDEMO_PCH_H
#define MACHINEDEMO_PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#endif //MACHINEDEMO_PCH_H
