# CSE335 Project 2
This is the starter project for CSE335 Project 2. It consists of these CMake projects:

1. CanadianExperience root project
2. CanadianExperienceLib library project
3. Tests unit testing for CanadianExperienceLib
4. MachineLib library project for machine
5. MachineDemo machine demonstrator
6. MachineTests testing for MachineLib
